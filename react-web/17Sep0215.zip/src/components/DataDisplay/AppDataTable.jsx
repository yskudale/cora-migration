import React, { useState, useMemo } from 'react';
import { useTheme } from '../../context/ThemeContext';
import AppContextMenu from '../Navigation/AppContextMenu';

export function AppDataTable({
  columns = [],
  headers = [],
  data = [],
  selectedRowId,
  selectedIndex,
  onSelectRow,
  onSortChange,
  onRowAction,
}) {
  const { theme } = useTheme();
  const isWindows = theme === 'windows';

  const [menuState, setMenuState] = useState({
    isOpen: false,
    x: 0,
    y: 0,
    activeRow: null,
  });
  const [currentSort, setCurrentSort] = useState('unsorted');

  // Normalize column configurations for backward compatibility
  const effectiveColumns = useMemo(() => {
    if (columns && columns.length > 0) return columns;
    if (headers && headers.length > 0) {
      const keyMap = {
        'Type': 'type',
        'Notes': 'notes',
        'Date Added': 'date',
        'By': 'by',
      };
      return headers.map((h) => ({
        key: keyMap[h] || h.toLowerCase().replace(/\s+/g, ''),
        header: h,
      }));
    }
    return [];
  }, [columns, headers]);

  const handleRowContextMenu = (e, row, index) => {
    e.preventDefault();
    e.stopPropagation();

    if (onSelectRow) {
      onSelectRow(row?.id !== undefined ? row : index);
    }

    setMenuState({
      isOpen: true,
      x: e.clientX,
      y: e.clientY,
      activeRow: row,
    });
  };

  const contextMenuItems = [
    {
      id: 'sort_by',
      label: 'Sort by',
      submenu: [
        {
          id: 'unsorted',
          label: '<unsorted>',
          checked: currentSort === 'unsorted',
          onClick: () => {
            setCurrentSort('unsorted');
            onSortChange?.('unsorted');
          },
        },
        ...effectiveColumns.map((col) => ({
          id: col.key,
          label: col.header,
          checked: currentSort === col.key,
          onClick: () => {
            setCurrentSort(col.key);
            onSortChange?.(col.key);
          },
        })),
      ],
    },
    { type: 'separator' },
    {
      id: 'post_changes',
      label: 'Post changes to current row',
      onClick: () => onRowAction?.('post', menuState.activeRow),
    },
    {
      id: 'cancel_changes',
      label: 'Cancel changes to current row',
      onClick: () => onRowAction?.('cancel', menuState.activeRow),
    },
    {
      id: 'insert_row',
      label: 'Insert new row',
      onClick: () => onRowAction?.('insert', menuState.activeRow),
    },
    {
      id: 'delete_row',
      label: 'Delete current row',
      onClick: () => onRowAction?.('delete', menuState.activeRow),
    },
  ];

  return (
    <div className="w-full overflow-x-auto">
      <table
        className={`w-full text-left border-collapse ${
          isWindows
            ? 'bg-white text-xs font-sans border-2 border-[#808080]'
            : 'bg-white dark:bg-slate-900 text-sm text-slate-700 dark:text-slate-200'
        }`}
      >
        <thead>
          <tr
            className={
              isWindows
                ? 'bg-[#F0EEEF] text-black border-b-2 border-[#808080]'
                : 'bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700'
            }
          >
            {effectiveColumns.map((col) => (
              <th
                key={col.key}
                className={`px-2 py-1 font-semibold ${
                  isWindows
                    ? 'border-r border-[#808080] shadow-[inset_1px_1px_0px_#ffffff]'
                    : ''
                }`}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, index) => {
            const rowId = row.id ?? index;
            const isSelected =
              selectedRowId !== undefined
                ? selectedRowId === row.id || selectedRowId === row
                : selectedIndex === index;

            return (
              <tr
                key={rowId}
                onClick={() => onSelectRow && onSelectRow(row.id ? row : index)}
                onContextMenu={(e) => handleRowContextMenu(e, row, index)}
                className={`cursor-pointer ${
                  isWindows
                    ? isSelected
                      ? 'bg-[#3375CC] text-white'
                      : 'hover:bg-gray-100 text-black'
                    : isSelected
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 font-medium'
                    : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                {effectiveColumns.map((col) => (
                  <td
                    key={col.key}
                    className={`px-2 py-1 whitespace-nowrap ${
                      isWindows ? 'border-r border-b border-[#e0e0e0]' : ''
                    }`}
                  >
                    {row[col.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>

      <AppContextMenu
        x={menuState.x}
        y={menuState.y}
        isOpen={menuState.isOpen}
        onClose={() => setMenuState((prev) => ({ ...prev, isOpen: false }))}
        items={contextMenuItems}
      />
    </div>
  );
}

export default AppDataTable;