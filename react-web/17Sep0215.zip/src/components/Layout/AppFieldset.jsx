import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppFieldset = ({ legend, legendColor = 'text-black', children, className = '' }) => {
  const { theme } = useTheme();

  if (theme === 'windows') {
    return (
      <fieldset className={`border border-[#808080] p-2.5 text-[11px] font-sans relative bg-[#F0EEEF] ${className}`}>
        {legend && (
          <legend className={`px-1 bg-[#F0EEEF] font-sans text-[11px] font-normal ${legendColor}`}>
            {legend}
          </legend>
        )}
        {children}
      </fieldset>
    );
  }

  return (
    <fieldset className={`border border-slate-200 rounded-xl p-4 relative bg-slate-50/50 ${className}`}>
      {legend && (
        <legend className="px-2 text-xs font-semibold text-slate-600 bg-white rounded-md border border-slate-200 shadow-xs">
          {legend}
        </legend>
      )}
      {children}
    </fieldset>
  );
};