import React, { useState } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { AppFormField } from '../Form/AppFormField';
import { AppInput } from '../Form/AppInput';
import { AppTextArea } from '../Form/AppTextArea';
import { AppPriorityRadioGroup } from './AppPriorityRadioGroup';
import { AppAttachmentPanel } from './AppAttachmentPanel';
import { AppFieldset } from '../Layout/AppFieldset';
import { AppButton } from '../Button/AppButton';

export const AppMessageForm = ({ 
  initialTo = 'ykudale Group-Apopka',
  initialAdmission = 'Request for Info: SYS1612398 Brandon Refstat Test',
  onSend, 
  onCancel, 
  onPrint,
  className = '',
  ...props 
}) => {
  const { theme } = useTheme();

  const [toField, setToField] = useState(initialTo);
  const [fromField, setFromField] = useState('');
  const [admissionField, setAdmissionField] = useState(initialAdmission);
  const [subjectField, setSubjectField] = useState('');
  const [itemRequestedField, setItemRequestedField] = useState('');
  const [priority, setPriority] = useState('High');
  const [message, setMessage] = useState('');
  const [replyFrom, setReplyFrom] = useState('');
  const [reply, setReply] = useState('');
  const [attachments, setAttachments] = useState([]);

  const handleAttach = () => {
    const fileName = prompt('Enter attachment file name:');
    if (fileName) {
      setAttachments([...attachments, { name: fileName }]);
    }
  };

  const handleRemoveAttach = (idx) => {
    setAttachments(attachments.filter((_, i) => i !== idx));
  };

  return (
    <div className={`space-y-3 ${theme === 'windows' ? 'font-sans text-[11px] text-black' : 'text-xs text-slate-800'} ${className}`} {...props}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <AppFormField label="To:">
          <AppInput value={toField} onChange={(e) => setToField(e.target.value)} className="w-full" />
        </AppFormField>

        <AppFormField label="From:">
          <AppInput value={fromField} onChange={(e) => setFromField(e.target.value)} className="w-full" />
        </AppFormField>

        <AppFormField label="Admission:">
          <AppInput value={admissionField} onChange={(e) => setAdmissionField(e.target.value)} className="w-full" />
        </AppFormField>

        <AppFormField label="Subject:">
          <AppInput value={subjectField} onChange={(e) => setSubjectField(e.target.value)} className="w-full" />
        </AppFormField>

        <AppFormField label="Item Requested:">
          <AppInput value={itemRequestedField} onChange={(e) => setItemRequestedField(e.target.value)} className="w-full" />
        </AppFormField>

        <AppPriorityRadioGroup value={priority} onChange={setPriority} />
      </div>

      <AppFieldset legend="Message">
        <AppTextArea 
          value={message} 
          onChange={(e) => setMessage(e.target.value)} 
          rows={4} 
          className="w-full" 
        />
      </AppFieldset>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        <AppFormField label="Reply From:">
          <AppInput value={replyFrom} onChange={(e) => setReplyFrom(e.target.value)} className="w-full" />
        </AppFormField>
      </div>

      <AppFieldset legend="Reply">
        <AppTextArea 
          value={reply} 
          onChange={(e) => setReply(e.target.value)} 
          rows={3} 
          className="w-full" 
        />
      </AppFieldset>

      <AppAttachmentPanel 
        attachments={attachments} 
        onAttachFile={handleAttach}
        onRemoveAttachment={handleRemoveAttach}
      />

      <div className="flex justify-between items-center pt-2">
        <AppButton onClick={onPrint}>Print</AppButton>
        <div className="flex gap-2">
          <AppButton 
            onClick={() => onSend && onSend({ toField, fromField, admissionField, subjectField, priority, message, reply, attachments })}
          >
            Send
          </AppButton>
          <AppButton onClick={onCancel}>Cancel</AppButton>
        </div>
      </div>
    </div>
  );
};