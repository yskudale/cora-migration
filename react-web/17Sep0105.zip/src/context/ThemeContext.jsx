import React, { createContext, useContext, useState } from 'react';

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  // Check URL query param ?theme=windows or default to 'windows'
  const queryParams = new URLSearchParams(window.location.search);
  const initialTheme = queryParams.get('theme') || 'windows';
  const [theme, setTheme] = useState(initialTheme);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);