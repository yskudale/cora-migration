import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { ScanningModule } from './modules/ScanningModule';
import { PatientSearchModule } from './modules/PatientSearchModule';
import { ComponentLibrary } from './pages/ComponentLibrary';

function MainApp() {
  const queryParams = new URLSearchParams(window.location.search);
  const activeModule = queryParams.get('module') || 'scanning';
  const { theme, setTheme } = useTheme();
  const [isClosed, setIsClosed] = useState(false);

  const handleClose = async () => {
    try {
      await fetch('http://localhost:8080/api/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'MODULE_CLOSED', module: activeModule })
      });
    } catch (err) {
      console.error(err);
    }
    setIsClosed(true);
    window.close();
  };

  if (isClosed) {
    return (
      <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
        <div className="bg-white p-6 rounded-xl shadow-md border border-slate-200 text-center font-sans">
          <h2 className="text-lg font-semibold text-slate-800">Module Closed</h2>
          <p className="text-sm text-slate-500 mt-1">You can safely return to the desktop application.</p>
        </div>
      </div>
    );
  }

  // Render Component Library Showcase Page
  if (activeModule === 'library') {
    return <ComponentLibrary />;
  }

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-4 ${theme === 'windows' ? 'bg-[#3A6EA5]' : 'bg-slate-100'}`}>

      {/* Theme Switcher Toolbar - updated to z-[2000] */}
      <div className="fixed top-4 right-4 bg-white p-2 rounded-lg shadow-xl border border-slate-300 flex items-center gap-2 z-[2000] text-xs font-sans text-slate-700">
        <span className="font-semibold">Current Theme:</span>
        <button
          onClick={() => setTheme('windows')}
          className={`px-3 py-1 rounded transition-colors ${theme === 'windows' ? 'bg-blue-600 text-white font-bold' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}
        >
          Windows Classic
        </button>
        <button
          onClick={() => setTheme('modern')}
          className={`px-3 py-1 rounded transition-colors ${theme === 'modern' ? 'bg-indigo-600 text-white font-bold' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'}`}
        >
          Modern Tailwind
        </button>
        <span className="mx-1 text-slate-300">|</span>

        <a
          href="?module=library"
          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-900 text-white font-medium text-xs no-underline"
        >
          Component Library
        </a>
      </div>

      {/* Render Active Application Module */}
      {activeModule === 'patient-search' ? (
        <PatientSearchModule onClose={handleClose} />
      ) : (
        <ScanningModule onClose={handleClose} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}