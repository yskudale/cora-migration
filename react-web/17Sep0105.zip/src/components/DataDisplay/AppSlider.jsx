import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppSlider = ({ 
  label, 
  value = 0, 
  onChange, 
  min = 0, 
  max = 120, 
  step = 10,
  className = '',
  ...props 
}) => {
  const { theme } = useTheme();
  const ticks = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120];

  if (theme === 'windows') {
    return (
      <div className={`font-sans text-[11px] select-none ${className}`} {...props}>
        {label && <div className="text-black font-normal mb-1">{label}: <span className="font-bold">{value}</span></div>}
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={onChange}
          className="w-full accent-[#0078D7] cursor-pointer"
        />
        {/* Tick labels */}
        <div className="flex justify-between text-[9px] text-black px-0.5">
          {ticks.map((t) => (
            <span key={t}>{t}</span>
          ))}
        </div>
      </div>
    );
  }

  // Modern Theme
  return (
    <div className={`space-y-1 ${className}`} {...props}>
      {label && (
        <div className="flex justify-between text-xs font-medium text-slate-700">
          <span>{label}</span>
          <span className="font-semibold text-indigo-600">{value}</span>
        </div>
      )}
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={onChange}
        className="w-full accent-indigo-600 cursor-pointer"
      />
      <div className="flex justify-between text-[10px] text-slate-400">
        <span>{min}</span>
        <span>{max / 2}</span>
        <span>{max}</span>
      </div>
    </div>
  );
};