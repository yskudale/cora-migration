import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { AppRadioButton } from '../Form/AppRadioButton';
import { AppLabel } from '../Form/AppLabel';

export const AppPriorityRadioGroup = ({ 
  value = 'Medium', 
  onChange, 
  name = 'priorityGroup',
  className = '',
  ...props 
}) => {
  const { theme } = useTheme();

  const options = [
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
    { label: 'Low', value: 'Low' }
  ];

  if (theme === 'windows') {
    return (
      <div className={`flex items-center gap-3 font-sans text-[11px] text-black ${className}`} {...props}>
        <AppLabel variant="bold">Priority:</AppLabel>
        <div className="flex items-center gap-2">
          {options.map((opt) => (
            <AppRadioButton
              key={opt.value}
              name={name}
              label={opt.label}
              value={opt.value}
              checked={value === opt.value}
              onChange={(e) => onChange && onChange(e.target.value)}
            />
          ))}
        </div>
      </div>
    );
  }

  // Modern Theme
  return (
    <div className={`flex items-center gap-4 ${className}`} {...props}>
      <AppLabel variant="bold">Priority</AppLabel>
      <div className="flex items-center gap-3">
        {options.map((opt) => (
          <AppRadioButton
            key={opt.value}
            name={name}
            label={opt.label}
            value={opt.value}
            checked={value === opt.value}
            onChange={(e) => onChange && onChange(e.target.value)}
          />
        ))}
      </div>
    </div>
  );
};