import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppTextArea = ({ 
  value, 
  onChange, 
  rows = 4, 
  readOnly = false,
  variant = 'default', // 'default', 'error' (red text)
  className = '', 
  ...props 
}) => {
  const { theme } = useTheme();

  if (theme === 'windows') {
    const textColor = variant === 'error' ? 'text-[#C00000] font-semibold' : 'text-black';
    return (
      <textarea
        value={value}
        onChange={onChange}
        rows={rows}
        readOnly={readOnly}
        className={`w-full bg-white border-2 border-t-[#7F9DB9] border-l-[#7F9DB9] border-b-white border-r-white p-1 font-sans text-[11px] outline-none resize-none ${textColor} ${className}`}
        {...props}
      />
    );
  }

  // Modern Theme
  const textColor = variant === 'error' ? 'text-rose-600 font-medium' : 'text-slate-800';
  return (
    <textarea
      value={value}
      onChange={onChange}
      rows={rows}
      readOnly={readOnly}
      className={`w-full p-2 border border-slate-300 rounded-lg text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none ${textColor} ${className}`}
      {...props}
    />
  );
};