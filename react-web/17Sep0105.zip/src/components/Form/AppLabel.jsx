import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppLabel = ({ 
  children, 
  variant = 'default', // 'default', 'bold', 'required', 'link', 'error'
  className = '',
  onClick,
  ...props 
}) => {
  const { theme } = useTheme();

  let variantStyles = '';
  
  if (theme === 'windows') {
    switch (variant) {
      case 'bold':
        variantStyles = 'font-bold text-black';
        break;
      case 'required':
        variantStyles = 'font-normal text-[#C00000]';
        break;
      case 'link':
        variantStyles = 'text-blue-800 underline cursor-pointer hover:text-blue-600';
        break;
      case 'error':
        variantStyles = 'font-bold text-[#C00000]';
        break;
      default:
        variantStyles = 'font-normal text-black';
    }
    return (
      <label 
        onClick={onClick}
        className={`font-sans text-[11px] select-none ${variantStyles} ${className}`} 
        {...props}
      >
        {children}
      </label>
    );
  }

  // Modern Theme
  switch (variant) {
    case 'bold':
      variantStyles = 'font-semibold text-slate-900';
      break;
    case 'required':
      variantStyles = 'font-medium text-rose-600';
      break;
    case 'link':
      variantStyles = 'text-indigo-600 hover:text-indigo-800 font-medium underline cursor-pointer';
      break;
    case 'error':
      variantStyles = 'font-semibold text-rose-600';
      break;
    default:
      variantStyles = 'font-medium text-slate-700';
  }

  return (
    <label 
      onClick={onClick}
      className={`text-xs ${variantStyles} ${className}`} 
      {...props}
    >
      {children}
    </label>
  );
};