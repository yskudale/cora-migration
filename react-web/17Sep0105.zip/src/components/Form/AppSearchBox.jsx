import React from 'react';
import { AppInput } from './AppInput';
import { AppButton } from '../Button/AppButton';

export const AppSearchBox = ({ 
  value, 
  onChange, 
  onSearch, 
  placeholder = 'Search...', 
  buttonLabel = 'Search',
  icon = '🔍',
  className = '',
  ...props 
}) => {
  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && onSearch) {
      onSearch(value);
    }
  };

  return (
    <div className={`flex items-center gap-1 ${className}`} {...props}>
      <AppInput
        value={value}
        onChange={onChange}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className="flex-1"
      />
      <AppButton icon={icon} onClick={() => onSearch && onSearch(value)}>
        {buttonLabel}
      </AppButton>
    </div>
  );
};