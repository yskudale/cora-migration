import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppSelect = ({ 
  value, 
  onChange, 
  options = [], 
  variant = 'default', // 'default', 'required'
  className = '', 
  children,
  ...props 
}) => {
  const { theme } = useTheme();

  if (theme === 'windows') {
    const bgClass = variant === 'required' ? 'bg-[#0078D7] text-white' : 'bg-white text-black';
    return (
      <select
        value={value}
        onChange={onChange}
        className={`border-2 border-t-[#7F9DB9] border-l-[#7F9DB9] border-b-white border-r-white p-0.5 font-sans text-[11px] outline-none cursor-pointer ${bgClass} ${className}`}
        {...props}
      >
        {children || options.map((opt, i) => (
          <option key={i} value={typeof opt === 'object' ? opt.value : opt} className="bg-white text-black">
            {typeof opt === 'object' ? opt.label : opt}
          </option>
        ))}
      </select>
    );
  }

  // Modern Theme
  return (
    <select
      value={value}
      onChange={onChange}
      className={`px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer ${className}`}
      {...props}
    >
      {children || options.map((opt, i) => (
        <option key={i} value={typeof opt === 'object' ? opt.value : opt}>
          {typeof opt === 'object' ? opt.label : opt}
        </option>
      ))}
    </select>
  );
};