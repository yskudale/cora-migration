import React from 'react';
import { useTheme } from '../../context/ThemeContext';

export const AppInput = ({ 
  value, 
  onChange, 
  placeholder, 
  type = 'text',
  readOnly = false,
  disabled = false,
  variant = 'default', // 'default', 'required' (pink fill)
  className = '', 
  ...props 
}) => {
  const { theme } = useTheme();

  if (theme === 'windows') {
    const bgClass = variant === 'required' ? 'bg-[#FFEFF2]' : (readOnly || disabled ? 'bg-[#ECE9D8]' : 'bg-white');
    return (
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        readOnly={readOnly}
        disabled={disabled}
        className={`border-2 border-t-[#7F9DB9] border-l-[#7F9DB9] border-b-white border-r-white px-1.5 py-0.5 font-sans text-[11px] text-black outline-none disabled:text-slate-500 ${bgClass} ${className}`}
        {...props}
      />
    );
  }

  // Modern Theme
  const bgClass = variant === 'required' ? 'bg-rose-50 border-rose-300' : 'bg-white border-slate-300';
  return (
    <input
      type={type}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
      readOnly={readOnly}
      disabled={disabled}
      className={`px-3 py-1.5 border rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:bg-slate-100 disabled:text-slate-400 transition-colors ${bgClass} ${className}`}
      {...props}
    />
  );
};