import React from 'react';
import { useTheme } from '../../context/ThemeContext';
import { AppLabel } from './AppLabel';

export const AppFormField = ({ 
  label, 
  required = false, 
  orientation = 'horizontal', // 'horizontal' | 'vertical'
  labelWidth = 'w-24',
  children, 
  className = '',
  ...props 
}) => {
  const { theme } = useTheme();

  if (orientation === 'vertical') {
    return (
      <div className={`flex flex-col gap-1 ${className}`} {...props}>
        {label && (
          <AppLabel variant={required ? 'required' : 'default'}>
            {label}{required && ' *'}
          </AppLabel>
        )}
        {children}
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2 ${className}`} {...props}>
      {label && (
        <div className={`shrink-0 ${labelWidth}`}>
          <AppLabel variant={required ? 'required' : 'default'}>
            {label}{required && ' *'}
          </AppLabel>
        </div>
      )}
      <div className="flex-1">{children}</div>
    </div>
  );
};